<?php

//first page load will be dirrect to admin dashboard
header('location:cn_admin.php');
?>